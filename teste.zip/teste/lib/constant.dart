import 'package:flutter/material.dart';

const List<Color> gradientColors = [
  Color(0xff0d47a1),
  Color(0xff1565c0),
  Color(0xff1976d2),
];
Color bubbleColor = const Color(0xff0d47a1);
Color buttonColor = const Color(0xff1565c0);